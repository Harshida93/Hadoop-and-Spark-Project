package org.spark.project2

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.sql.SQLContext._

object Practice {
  def main(args:Array[String]){
    val conf = (new SparkConf)
    .setAppName("SparkProject")
    .setMaster("local[*]")
    
    val sc = new SparkContext(conf)
    
    val spksession = SparkSession.builder()
    .appName("SparkProject")
    .master("local[*]")
    .getOrCreate()
    
    import spksession.implicits._
    
  val df = spksession.createDataFrame(Seq((0, "a"), (1, "b"), (2, "c"), (3, "a"), (4, "a"), (5, "c"))).toDF("id","Category")
 
  df.show()
  
  val indexer = new StringIndexer().setInputCol("Category").setOutputCol("Cat_index").fit(df)
 
    val newDf = indexer.transform(df)
    
    newDf.show()
    
  
}
      
    
}