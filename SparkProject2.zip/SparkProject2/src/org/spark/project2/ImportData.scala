package org.spark.project2

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, udf}
import java.text.SimpleDateFormat
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.classification.GBTClassifier
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.feature.StringIndexer
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.tuning.{ ParamGridBuilder, CrossValidator }
import org.apache.spark.ml.{ Pipeline, PipelineStage }

object ImportData {
  
  def main(args:Array[String]){
    val conf = (new SparkConf)
    .setAppName("SparkProject")
    .setMaster("local[*]")
    
    val sc = new SparkContext(conf)
    
    val spksession = SparkSession.builder()
    .appName("SparkProject")
    .master("local[*]")
    .getOrCreate()
    
    //Importing the dataset
    
    val rdd = sc.textFile("/Users/harshida/Documents/BDA 105/SparkProject/Spark_data_numerical4.csv")
    .map(row=>{
      val cols = row.split(",")
      new Data(cols(0).toDouble,cols(1).toDouble,cols(2).toDouble,cols(3).toDouble,cols(4).toDouble,cols(5).toDouble,cols(6).toDouble,cols(7).toDouble,cols(8).toDouble,cols(9).toDouble,cols(10).toDouble,cols(11).toDouble,
         cols(12).toDouble,cols(13).toDouble,cols(14).toDouble,cols(15).toDouble,cols(16).toDouble,cols(17).toDouble,cols(18).toDouble,cols(19).toDouble,cols(20).toDouble,cols(21).trim().toDouble,cols(22).toDouble,cols(23).toDouble,cols(24).toDouble,cols(25).toDouble,cols(26).toDouble,cols(27).toDouble,cols(28).toDouble,
         cols(29).toDouble,cols(30).toDouble,cols(31).toDouble,cols(32).toDouble,
         cols(33).toDouble,cols(34).toDouble,cols(35).toDouble,cols(36).toDouble)
    })
    
     val rdd1 = sc.textFile("/Users/harshida/Documents/BDA 105/SparkProject/Spark_data_numerical3.csv")
    .map(row=>{
      val cols = row.split(",")
      new Data(cols(0).toDouble,cols(1).toDouble,cols(2).toDouble,cols(3).toDouble,cols(4).toDouble,cols(5).toDouble,cols(6).toDouble,cols(7).toDouble,cols(8).toDouble,cols(9).toDouble,cols(10).toDouble,cols(11).toDouble,
         cols(12).toDouble,cols(13).toDouble,cols(14).toDouble,cols(15).toDouble,cols(16).toDouble,cols(17).toDouble,cols(18).toDouble,cols(19).toDouble,cols(20).toDouble,cols(21).trim().toDouble,cols(22).toDouble,cols(23).toDouble,cols(24).toDouble,cols(25).toDouble,cols(26).toDouble,cols(27).toDouble,cols(28).toDouble,
         cols(29).toDouble,cols(30).toDouble,cols(31).toDouble,cols(32).toDouble,
         cols(33).toDouble,cols(34).toDouble,cols(35).toDouble,cols(36).toDouble)
    })
    
    
   val LoanDf =spksession.read.option("header", true).option("inferSchema", true).csv("/Users/harshida/Documents/BDA 105/SparkProject/Spark_data_numerical3.csv")
   //LoanDf.show(10)
   val LoanDfCategorical = spksession.read.option("header", true).option("inferSchema", true).csv("/Users/harshida/Documents/BDA 105/SparkProject/Dataset 2.csv")
   val df1 = new StringIndexer().setInputCol("name_contract_type").setOutputCol("name_contract_type_idx")
   .fit(LoanDfCategorical).transform(LoanDfCategorical)
   val df2 = new StringIndexer().setInputCol("code_gender").setOutputCol("code_gender_idx")
   .fit(df1).transform(df1)
   val df3 = new StringIndexer().setInputCol("flag_own_car").setOutputCol("flag_own_car_idx")
   .fit(df2).transform(df2)
   val df4 = new StringIndexer().setInputCol("flag_own_realty").setOutputCol("flag_own_realty_idx")
   .fit(df3).transform(df3)
   val df5 = new StringIndexer().setInputCol("name_income_type").setOutputCol("name_income_type_idx")
   .fit(df4).transform(df4)
   val df6 = new StringIndexer().setInputCol("name_education_type").setOutputCol("name_education_type_idx")
   .fit(df5).transform(df5)
   val df7 = new StringIndexer().setInputCol("name_family_status").setOutputCol("name_family_status_idx")
   .fit(df6).transform(df6)
   val df8 = new StringIndexer().setInputCol("name_housing_type").setOutputCol("name_fhousing_type_idx")
   .fit(df7).transform(df7)
   val df9 = new StringIndexer().setInputCol("organization_type").setOutputCol("organization_type_idx")
   .fit(df8).transform(df8)
   
   //df9.show(10)
   val columns_to_drop = Array("name_contract_type","code_gender","flag_own_car","flag_own_realty","name_income_type","name_education_type",
                               "name_family_status","name_housing_type","organization_type")
     val df10 = df9.drop("name_contract_type","code_gender","flag_own_car","flag_own_realty","name_income_type","name_education_type","name_family_status","name_housing_type","organization_type")                          
   //df10.show(10)
   //LoanDfCategorical.show(10)
   
   //DATA ANALYSIS  USING SparkSession.sql and SparkContext
   
   import spksession.implicits._
    val df = rdd.toDF()
    //df.show(10)
    df.registerTempTable("CreditTable")
    spksession.sql("select target ,count(target),avg(amt_income_total) as avg_income,avg(amt_credit)as avg_credit,avg(amt_annuity) as avg_annuity from CreditTable group by target").show
    //df.groupBy("target").avg("amt_income_total").show()   
    //df.describe("target").show()
   // df.groupBy("target").count().show()
    LoanDfCategorical.registerTempTable("EligibleDfCat")
//spksession.sql("Select count(*),code_gender from EligibleDfCat group by code_gender").show()
//spksession.sql("Select count(*) as total , name_education_type,code_gender from EligibleDfCat group by name_education_type,code_gender order by total").show()
//spksession.sql("Select avg(amt_credit) , code_gender from EligibleDfCat group by code_gender").show()
spksession.sql("Select count(name_contract_type) from EligibleDfCat where name_contract_type = 'Cash loans'")
    
    val eligibleDf = rdd1.toDF()
    eligibleDf.registerTempTable("EligibleTable")  
    //Transforming all columns to one single vector as it can be fed into the classifier.
     
    
    //PREDICTIVE MODELLING USING SPARK- DID JUST FOR MY OWN KNOWLEDGE
    
 /* val Featurecolumns = Array("name_contract_type","code_gender","flag_own_car","flag_own_realty",
         "cnt_children","amt_income_total","amt_credit","amt_annuity","name_income_type",
         "name_education_type","name_family_status","name_housing_type","days_birth"
         ,"days_employed","flag_mobil","flag_emp_phone","flag_work_phone",
         "flag_cont_mobile","flag_phone","cnt_fam_members","region_rating_client",
         "region_rating_client_w_city","reg_region_not_live_region","reg_region_not_work_region",
         "organization_type","flag_document_2","flag_document_3","flag_document_4"	,"flag_document_5",
         "flag_document_6","flag_document_7","flag_document_8","flag_document_9",
        "flag_document_10","flag_document_11","flag_document_12")
   
   
  val assembler = new VectorAssembler().setInputCols(Featurecolumns).setOutputCol("features")
  
   val labelIndex = new StringIndexer().setInputCol("target").setOutputCol("label")
   val numDf = assembler.transform(df)
  val newDf = labelIndex.fit(numDf).transform(numDf)
    //newDf.show(10)
 
 //Building the model using RandomForestClassifier and evaluating the model accuracy       
        
val randomseed = 1
def balanceDataset(newDf: DataFrame): DataFrame = {

    // Re-balancing (weighting) of records to be used in the logistic loss objective function
    val numNegatives = newDf.filter(newDf("label") === 1).count
    val datasetSize = newDf.count
    val balancingRatio = (datasetSize - numNegatives).toDouble / datasetSize

    val calculateWeights = udf { d: Double =>
      if (d == 1.0) {
        1 * balancingRatio
      }
      else {
        (1 * (0.0 - balancingRatio))
      }
    }

    val weightedDataset = newDf.withColumn("classWeightCol", calculateWeights(newDf("label")))
    weightedDataset
  }
val Array(trainData,testData) = newDf.randomSplit(Array(0.7,0.3),randomseed)

//val clf = new RandomForestClassifier().setMaxDepth(3).setImpurity("gini")
//.setNumTrees(20).setFeatureSubsetStrategy("auto").setSeed(randomseed)

//val clf = new RandomForestClassifier()

   

val clf = new LogisticRegression()

val model = clf.fit(trainData)
val pred=model.probabilityCol
val prediction = model.transform(testData)
//val prediction = model.transform(trainData)
val x =prediction.select("target","rawPrediction", "probability","prediction").where("prediction=0.0")
x.show(100)
val eval = new BinaryClassificationEvaluator().setLabelCol("label")
val acc = eval.evaluate(prediction)
println(acc)
//df.show(10)

//hyperparameter tuning
//val paramGrid = new ParamGridBuilder()
// .addGrid(clf.maxBins, Array(25, 28, 31))
 //.addGrid(clf.maxDepth, Array(4, 6, 8))
 // .addGrid(clf.impurity, Array("entropy", "gini"))
 //.build()
  
// val steps: Array[PipelineStage] = Array(clf)
//val pipeline = new Pipeline().setStages(steps)

//val evaluator = new BinaryClassificationEvaluator()
  //.setLabelCol("label")
//val cv = new CrossValidator()
  //.setEstimator(pipeline)
  //.setEvaluator(evaluator)
  //.setEstimatorParamMaps(paramGrid)
  //.setNumFolds(10)
 // val pipelineFittedModel = cv.fit(trainData)
 // val predictions = pipelineFittedModel.transform(testData)
//val accuracy = evaluator.evaluate(predictions)
//println(accuracy)

//val x =predictions.select("target","rawPrediction", "probability","prediction").where("prediction=1.0")
//x.show()*/

//spksession.sql("Select count(*),code_gender from EligibleTable group by code_gender").show()



   
   
   
   
   
   
   
   
   
   
   
   
}
}
   
  

