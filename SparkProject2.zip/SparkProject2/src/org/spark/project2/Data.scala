

package org.spark.project2

case class Data(target:Double, name_contract_type:Double,	code_gender:Double,
    flag_own_car:Double	,flag_own_realty:Double,	cnt_children:Double ,	amt_income_total:Double,
    amt_credit:Double,	amt_annuity: Double,	name_income_type:Double,	name_education_type:Double,
    name_family_status:Double,	name_housing_type:Double,	days_birth:Double,	days_employed:Double,
    flag_mobil:Double,	flag_emp_phone:Double,	flag_work_phone:Double,	flag_cont_mobile:Double,	flag_phone:Double,
    cnt_fam_members:Double,	region_rating_client:Double,	region_rating_client_w_city:Double,	reg_region_not_live_region:Double,
    reg_region_not_work_region:Double,	organization_type:Double	,flag_document_2:Double,	flag_document_3:Double,
    flag_document_4	:Double,flag_document_5:Double,	flag_document_6:Double,	flag_document_7:Double,flag_document_8:Double,
    flag_document_9	:Double,flag_document_10:Double,flag_document_11:Double,	flag_document_12:Double){}
