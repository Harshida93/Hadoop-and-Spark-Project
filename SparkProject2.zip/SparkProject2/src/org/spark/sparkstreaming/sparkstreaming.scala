

package org.spark.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._

object sparkstreaming {
  def main(args:Array[String]){
  val conf = (new SparkConf).setAppName("Spark Streaming").setMaster("local[*]")
  val sc = new SparkContext(conf)
  
  val streamingContext = new StreamingContext(sc, Seconds(6))
  
  
  val DSstream1 = streamingContext.socketTextStream("localhost", 21)
  val DSstream2 = streamingContext.socketTextStream("localhost", 22)
  val union = DSstream1.union(DSstream2)
  union.print()
  //val pairs = DSstream.flatMap(_.split(" ")).map(word => (word,1))
  
 // val wordCount = pairs.reduceByKey(_+_)
  
  streamingContext.start()
  streamingContext.awaitTermination()
  //streamingContext.stop(false)
  //println(sc.isStopped)
  
  
}
  
}